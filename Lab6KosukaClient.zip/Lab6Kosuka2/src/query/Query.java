package query;

public class Query {
	public static String query1(int avgrade, int year) {
		return String.format("SELECT NAME, AVGRADE FROM STUDENT"
				+ " WHERE YEARUNI = %d AND AVGRADE > %d ORDER BY AVGRADE DESC", year, avgrade);
	}
	public static String query2(String degree, int lessonId) {
		return String.format("SELECT * FROM TEACHER"
				+ " WHERE DEGREE='%s' AND IDLESSON=%d", degree, lessonId);
	}
}
