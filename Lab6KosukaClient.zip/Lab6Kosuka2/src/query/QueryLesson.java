package query;

import java.util.Map;

public class QueryLesson {
	public static String queryCreate() {
		String sql = "create table Lesson ("
				+ "ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),"
				+ "NAME varchar(30) default '' not null, " 
				+ "CREDITS integer default 0 CHECK (CREDITS>2 AND CREDITS<6), "
				+ "HASLABS int not NULL default 0 CHECK (HASLABS IN(1, 0)),"
				+ "primary key (ID))";
		return sql;
	}
	public static String querryGetAll() {
		return "select LESSON.ID, LESSON.NAME, LESSON.CREDITS, LESSON.HASLABS"
		+ "ORDER BY LESSON.NAME"; 
	}
	
	public static String queryAdd(Map<String, Object> map) {
		return String.format("INSERT INTO LESSON" + "(NAME, CREDITS, HASLABS)"
		+"values('%s', %d, %d)", map.get("name"), map.get("credits"), map.get("hasLabs"));
	}
	
	public static String queryEdit(Map<String, Object> map) {
		return String.format("UPDATE LESSON" 
		+ " SET NAME = '%s', CREDITS = %d, HASLABS = %d WHERE ID=%d", 
		map.get("name"), map.get("credits"), map.get("hasLabs"), map.get("id"));
	}
	
	public static String queryDelById(int id) {
		return "DELETE FROM LESSON WHERE ID = " + id;
	}
}
