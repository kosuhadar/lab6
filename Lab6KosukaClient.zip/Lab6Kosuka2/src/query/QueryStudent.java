package query;

import java.util.Map;

public class QueryStudent {
	
	public static String queryCreate() {
		String sql = "create table STUDENT("
		+ "ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),"
		+ "NAME varchar(60) default '' not null, "
		+ "YEARUNI int CHECK (YEARUNI>0 AND YEARUNI<7),"
		+ "AVGRADE int, "
		+ "IDTEACHER int constraint FK_STUDENT_TEACHER "
		+ "references TEACHER on delete CASCADE,"
		+ "primary key (ID))";
		return sql;
	}
	
	public static String queryGetAll() {
		return "select STUDENT.ID, STUDENT.NAME, STUDENT.YEARUNI, STUDENT.AVGRADE"
				+ "TEACHER.NAME AS TEACHER, TEACHER.ID AS IDTEACHER"
				+ "FROM STUDENT, TEACHER"
				+ "WHERE TEACHER.ID=STUDENT.IDTEACHER"
				+ "ORDER BY TEACHER, STUDENT.NAME";  
	}
	public static String queryAdd(Map<String, Object> map) {
		return String.format("INSERT INTO STUDENT" + "(NAME, YEARUNI, AVGRADE, IDTEACHER)"
		+" values('%s', %d, %d, %d)", map.get("name"), map.get("year"), map.get("avgrade"), map.get("idTeacher"));
	}
	
	public static String queryEdit(Map<String, Object> map) {
		return String.format("UPDATE STUDENT" 
		+ "SET NAME = '%s', YEARUNI = %d, AVGRADE = %d,"
		+ "IDTEACHER = %d WHERE ID = %d", map.get("name"), map.get("year"), map.get("avgrade"), map.get("idTeacher"), map.get("id"));
	}
	
	public static String queryDelById(int id) {
		return "DELETE FROM STUDENT WHERE ID = " + id;
	}
	
	public static String queryGetForLesson(int idTeacher) {
		return String.format("SELECT STUDENT.ID, STUDENT.NAME, STUDENT.YEARUNI, STUDENT.AVGRADE FROM STUDENT"
		+ "WHERE STUDENT.IDTEACHER = %d " + "ORDER BY STUDENT.NAME", idTeacher);
	}
}
