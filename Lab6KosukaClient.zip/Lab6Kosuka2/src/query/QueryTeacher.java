package query;

import java.util.Map;

public class QueryTeacher {
	
	public static String queryCreate() {
		String sql = "create table TEACHER(" 
		+ "ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),"
		+ "NAME varchar(60) default '' not null,"
		+ "DEGREE varchar(30),"
		+ "RATING int CHECK(RATING>0 AND RATING<101),"
		+ "IDLESSON int constraint FK_TEACHER_LESSON "
		+ "references LESSON on delete CASCADE,"
		+ "primary key (ID))";
		return sql;
	}
	
	public static String queryGetAll() {
		return "select TEACHER.ID, TEACHER.NAME, TEACHER.DEGREE, TEACHER.RATING"
		+ "LESSON.NAME AS LESSON, LESSON.ID AS IDLESSON"
		+ "FROM TEACHER, LESSON"
		+ "WHERE LESSON.ID=TEACHER.IDLESSON"
		+ "ORDER BY LESSON, TEACHER.NAME"; 
	}
	
	public static String queryAdd(Map<String, Object> map) {
		return String.format("INSERT INTO TEACHER" + "(NAME, DEGREE, RATING, IDLESSON)"
		+"values('%s', '%s', %d, %d)", map.get("name"), map.get("degree"), map.get("rating"), map.get("idLesson"));
	}
	
	public static String queryEdit(Map<String, Object> map) {
		return String.format("UPDATE TEACHER" 
		+ "SET NAME = '%s', DEGREE = '%s', RATING = %d,"
		+ "IDLESSON = %d WHERE ID = %d", map.get("name"), map.get("degree"), map.get("rating"), map.get("idLesson"), map.get("id"));
	}
	
	public static String queryDelById(int id) {
		return "DELETE FROM TEACHER WHERE ID = " + id;
	}
	
	public static String queryGetForLesson(int idLesson) {
		return String.format("SELECT TEACHER.ID, TEACHER.NAME, TEACHER.DEGREE, TEACHER.RATING FROM TEACHER"
		+ "WHERE TEACHER.IDLESSON = %d " + "ORDER BY TEACHER.NAME", idLesson);
	}
}
