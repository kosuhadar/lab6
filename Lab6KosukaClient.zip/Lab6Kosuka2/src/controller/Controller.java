package controller;

import java.lang.reflect.Method;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import view.DlgSelect;

public class Controller {
	private static String dbFullName = null;

	public static void setDbFullName(String dbFllName) {
		Controller.dbFullName =dbFllName;
	}
	private static String getDbFullName() {	
		if(dbFullName==null) {
			dbFullName = JOptionPane.showInputDialog(null, 
					"Enter DB full name", "d:/dbKosukha");
		}
		return dbFullName;
	}


	private static List<Map<String, Object>>  stringToMapList(String result) {
		List<Map<String, Object>> list = new ArrayList<>();
		try {
			JSONArray ar = new JSONArray(result);		
			for (int i = 0; i < ar.length(); i++) {
				JSONObject obj = (JSONObject) ar.get(i);
				Map<String, Object> map = new LinkedHashMap<>();
				Iterator<String> itr = obj.keys();
				while (itr.hasNext()) {
					String key =  itr.next();
					map.put(key,obj.get(key));
				}
				list.add(map);
				}
			} catch (JSONException e) {
			e.printStackTrace();
		}
		return list;
	}

	private static HttpClient httpClient = HttpClientBuilder.create().build();
	private static URIBuilder bd;
	
	public static String executeRequest(HttpRequestBase request){	
	try {
		HttpResponse response = httpClient.execute(request);
		int code = response.getStatusLine().getStatusCode();
		if (code != 200)
			return "ERROR! "+response.getStatusLine().toString();
			HttpEntity entity = response.getEntity();
			return EntityUtils.toString(entity);		
		} catch (Exception e) {
			return "ERROR! "+e.getStackTrace()[0].toString();
		}
	}

	public static boolean tableExist(String tableName) {
		String db = getDbFullName();
		String uri = "http://localhost:8080/Lab6Kosukha"
				+ "/rest/lab6/exist/"+ tableName +"/";
		try {		
			bd = new URIBuilder(uri);
			bd.addParameter("db", db);
			String res = executeRequest(new HttpGet(bd.build()));
			return res != null && res.equals("true");
		} catch (URISyntaxException e) {
			e.printStackTrace();
			return false;
		}	

	}
	
	public static List<Map<String, Object>> executeQuery(String query){
		String db = getDbFullName();
		String uri = "http://localhost:8080/Lab6Kosukha"
				+ "/rest/lab6/execute/";	
		String result="";
		try {
			bd = new URIBuilder(uri);
			bd.addParameter("db", db);
			bd.addParameter("query", query);
			System.out.println(bd + "\n executeQuery");
			result = executeRequest(new HttpGet(bd.build()));
			return stringToMapList(result);
		} catch (URISyntaxException e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}


	
	public static int executeUpdate(String query) {
		String db = getDbFullName();
		String uri = "http://localhost:8080/Lab6Kosukha"
				+ "/rest/lab6/update/";
		try {		
			bd = new URIBuilder(uri);
			bd.addParameter("db", db);
			bd.addParameter("query", query);
			String res = executeRequest(new HttpPost(bd.build()));
			System.out.println(bd + "\n executeUpdate");
			return Integer.parseInt(res);
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}	

	}

	public static int createTable(String tableName) {
		try {
			String queryClass = "query.Query" + tableName;
			Class<?> clz = Class.forName(queryClass);
			Method mtd = clz.getMethod("queryCreate");
			String sql = (String) mtd.invoke(null);
			int n = Controller.executeUpdate(sql);
			return n;
		} catch (Exception e1) {
			e1.printStackTrace();
			return 0;
		}
	}

	public static void add(String tableName, 	Map<String, Object> map) {
		try {
			String queryClass = "query.Query" + tableName;
			Class<?> clz = Class.forName(queryClass);
			Method mtd = clz.getMethod("queryAdd",Map.class);
			String sql = (String) mtd.invoke(null,map);
			Controller.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

	public static void edit(String tableName, Map<String, Object> map) {
		try {
			String queryClass = "query.Query" + tableName;
			Class<?> clz = Class.forName(queryClass);
			Method mtd = clz.getMethod("queryEdit", Map.class);
			String sql = (String) mtd.invoke(null,map);
			Controller.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

	public static void delete(String tableName, Map<String, Object> map) {
		try {
			String queryClass =  "query.Query" + tableName;	
			Class<?> clz = Class.forName(queryClass);
			Method mtd = clz.getMethod("queryDelById", int.class);
			int id = (Integer)map.get("id");
			String sql = (String) mtd.invoke(null,id);
			Controller.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

	public static List<Map<String, Object>> getAll(String tableName) {
		String db = getDbFullName();
		String uri = "http://localhost:8080/Lab6Kosukha"
				+ "/rest/lab6/execute/";	
		String result="";
		try {
			bd = new URIBuilder(uri);
			bd.addParameter("db", db);
			bd.addParameter("query", "select * from " + tableName);
			result = executeRequest(new HttpGet(bd.build()));
			return stringToMapList(result);
		} catch (URISyntaxException e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}


}
