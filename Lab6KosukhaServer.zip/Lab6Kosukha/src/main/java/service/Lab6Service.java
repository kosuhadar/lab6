package service;

import java.util.List;
import java.util.Map;

import controller.Controller;
import controller.DbConnector;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/lab6")
public class Lab6Service {	
	@GET
	@Path("/test")
	@Produces(MediaType.TEXT_PLAIN)
	public String test() {
		return "Test done!";
	}
	@GET
	@Path("/exist/{table}")
	@Produces(MediaType.TEXT_PLAIN)
	public String tableExist(
			@PathParam("table") String table,
			@QueryParam("db") String db	) {
		
		DbConnector.setDbFullName(db);
		Boolean b = Controller.tableExist(table.toUpperCase());
		return b.toString();
	}
	@POST
	@Path("/create/{table}")
	@Produces(MediaType.TEXT_PLAIN)
	public String createTable(
			@PathParam("table") String table,
			@QueryParam("db") String db	) {
		
		DbConnector.setDbFullName(db);
		int n = Controller.createTable(table);
		return Integer.toString(n);
	}
	@GET
	@Path("/execute/")
	@Produces(MediaType.TEXT_PLAIN)
	public String execute(	
				@QueryParam("db") String db,
				@QueryParam("query") String query) {
		
		DbConnector.setDbFullName(db);
		List<Map<String, Object>> mapList = 
				Controller.executeQuery(query);
		return mapList.toString();
	}
	@POST
	@Path("/update/")
	@Produces(MediaType.TEXT_PLAIN)
	public int executeUpdate(	
				@QueryParam("db") String db,
				@QueryParam("query") String query) {
		
		DbConnector.setDbFullName(db);
		int n = Controller.executeUpdate(query);
		return n;
	}
}


